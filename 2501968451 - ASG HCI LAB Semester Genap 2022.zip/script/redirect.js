function home(){
    window.open("../html/index.html", "_self");
}

function marineLife(){
    window.open("../html/marineLife.html", "_self");
}

function marineAnimals(){
    window.open("../html/marineAnimals.html", "_self");
}

function aboutUs(){
    window.open("../html/aboutUs.html", "_self");
}

function contactUs(){
    window.open("../html/contactUs.html", "_self");
}

function mammalsGallery(){
    window.open("../html/mammalsGallery.html", "_self");
}

function vertebratesGallery(){
    window.open("../html/vertebratesGallery.html", "_self");
}

function invertebratesGallery(){
    window.open("../html/invertebratesGallery.html", "_self");
}